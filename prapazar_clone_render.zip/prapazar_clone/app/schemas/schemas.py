# ============================================
# PYDANTIC ŞEMALARI (API Request/Response Modelleri)
# ============================================

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime
from decimal import Decimal


# ========== KULLANICI ŞEMALARI ==========

class UserBase(BaseModel):
    email: str
    full_name: Optional[str] = None
    role: str = "user"

class UserCreate(UserBase):
    password: str = Field(..., min_length=6)

class UserResponse(UserBase):
    id: int
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True

class UserLogin(BaseModel):
    email: str
    password: str

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


# ========== MAĞAZA ŞEMALARI ==========

class StoreBase(BaseModel):
    name: str
    platform: str = Field(..., pattern="^(trendyol|hepsiburada|n11|gg|ciceksepeti)$")
    api_key: Optional[str] = None
    api_secret: Optional[str] = None
    seller_id: Optional[str] = None
    is_active: bool = True

class StoreCreate(StoreBase):
    pass

class StoreUpdate(BaseModel):
    name: Optional[str] = None
    api_key: Optional[str] = None
    api_secret: Optional[str] = None
    seller_id: Optional[str] = None
    is_active: Optional[bool] = None

class StoreResponse(StoreBase):
    id: int
    user_id: int
    last_sync_at: Optional[datetime]
    created_at: datetime

    class Config:
        from_attributes = True


# ========== ÜRÜN ŞEMALARI ==========

class ProductBase(BaseModel):
    sku: str = Field(..., min_length=1, max_length=255)
    barcode: Optional[str] = None
    title: str = Field(..., min_length=1, max_length=500)
    description: Optional[str] = None
    brand: Optional[str] = None
    category_id: Optional[int] = None
    base_price: Decimal = Field(..., ge=0)
    base_stock: int = Field(default=0, ge=0)
    images: Optional[List[str]] = []
    attributes: Optional[Dict[str, Any]] = {}
    is_active: bool = True

class ProductCreate(ProductBase):
    pass

class ProductUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    brand: Optional[str] = None
    base_price: Optional[Decimal] = None
    base_stock: Optional[int] = None
    images: Optional[List[str]] = None
    attributes: Optional[Dict[str, Any]] = None
    is_active: Optional[bool] = None

class ProductResponse(ProductBase):
    id: int
    user_id: int
    created_at: datetime
    updated_at: Optional[datetime]

    class Config:
        from_attributes = True


# ========== LİSTELEME ŞEMALARI ==========

class ProductListingBase(BaseModel):
    product_id: int
    store_id: int
    platform_price: Optional[Decimal] = None
    platform_stock: Optional[int] = None
    commission_rate: Decimal = Field(default=0, ge=0, le=100)

class ProductListingCreate(ProductListingBase):
    pass

class ProductListingResponse(ProductListingBase):
    id: int
    platform_product_id: Optional[str]
    platform_sku: Optional[str]
    listing_status: str
    last_sync_at: Optional[datetime]
    sync_error: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True


# ========== SİPARİŞ ŞEMALARI ==========

class OrderItemBase(BaseModel):
    product_id: Optional[int] = None
    quantity: int = Field(..., ge=1)
    unit_price: Optional[Decimal] = None
    total_price: Optional[Decimal] = None

class OrderItemResponse(OrderItemBase):
    id: int

    class Config:
        from_attributes = True

class OrderBase(BaseModel):
    platform_order_id: str
    platform: str
    order_number: Optional[str] = None
    customer_name: Optional[str] = None
    customer_phone: Optional[str] = None
    customer_address: Optional[str] = None
    total_amount: Optional[Decimal] = None
    currency: str = "TRY"
    status: str = "Created"
    cargo_company: Optional[str] = None
    tracking_number: Optional[str] = None
    order_date: Optional[datetime] = None

class OrderResponse(OrderBase):
    id: int
    store_id: int
    items: List[OrderItemResponse] = []
    created_at: datetime

    class Config:
        from_attributes = True


# ========== SENKRONİZASYON ŞEMALARI ==========

class SyncRequest(BaseModel):
    store_id: int
    sync_type: str = Field(..., pattern="^(products|orders|stock|price)$")

class SyncLogResponse(BaseModel):
    id: int
    store_id: int
    sync_type: str
    status: str
    items_processed: int
    items_failed: int
    error_message: Optional[str]
    started_at: Optional[datetime]
    completed_at: Optional[datetime]
    created_at: datetime

    class Config:
        from_attributes = True


# ========== TOPLU İŞLEM ŞEMALARI ==========

class BulkProductUpload(BaseModel):
    products: List[ProductCreate]

class BulkPriceUpdate(BaseModel):
    updates: List[Dict[str, Any]]  # [{"product_id": 1, "new_price": 100}]

class BulkStockUpdate(BaseModel):
    updates: List[Dict[str, Any]]  # [{"product_id": 1, "new_stock": 50}]


# ========== DASHBOARD / RAPOR ŞEMALARI ==========

class DashboardStats(BaseModel):
    total_products: int
    total_stores: int
    total_orders_today: int
    pending_orders: int
    total_revenue_today: Decimal
    last_sync_status: Optional[str]

class StoreSyncStatus(BaseModel):
    store_id: int
    store_name: str
    platform: str
    last_sync_at: Optional[datetime]
    product_count: int
    order_count_today: int
    is_active: bool
