"""Kategori yönetimi endpoint'leri."""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List

from app.api.deps import get_db, get_current_user
from app.crud.category import category_crud
from app.schemas.category import CategoryCreate, CategoryUpdate, CategoryResponse
from app.models.user import User

router = APIRouter(prefix="/categories", tags=["Kategoriler"])


@router.get("/", response_model=List[CategoryResponse])
async def list_categories(
    skip: int = 0,
    limit: int = 100,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Kategorileri listele."""
    return await category_crud.get_by_owner(db, owner_id=current_user.id, skip=skip, limit=limit)


@router.get("/tree", response_model=List[CategoryResponse])
async def get_category_tree(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Kategori ağacını getir."""
    return await category_crud.get_root_categories(db, owner_id=current_user.id)


@router.post("/", response_model=CategoryResponse, status_code=status.HTTP_201_CREATED)
async def create_category(
    category_in: CategoryCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Yeni kategori ekle."""
    category_data = category_in.model_dump()
    category_data["owner_id"] = current_user.id

    category = await category_crud.create(db, obj_in=category_data)
    return category


@router.get("/{category_id}", response_model=CategoryResponse)
async def get_category(
    category_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Kategori detayı."""
    category = await category_crud.get(db, id=category_id)
    if not category or category.owner_id != current_user.id:
        raise HTTPException(status_code=404, detail="Kategori bulunamadı")
    return category


@router.put("/{category_id}", response_model=CategoryResponse)
async def update_category(
    category_id: int,
    category_update: CategoryUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Kategori güncelle."""
    category = await category_crud.get(db, id=category_id)
    if not category or category.owner_id != current_user.id:
        raise HTTPException(status_code=404, detail="Kategori bulunamadı")

    updated = await category_crud.update(db, db_obj=category, obj_in=category_update)
    return updated


@router.delete("/{category_id}")
async def delete_category(
    category_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Kategori sil."""
    category = await category_crud.get(db, id=category_id)
    if not category or category.owner_id != current_user.id:
        raise HTTPException(status_code=404, detail="Kategori bulunamadı")

    await category_crud.remove(db, id=category_id)
    return {"message": "Kategori başarıyla silindi"}
