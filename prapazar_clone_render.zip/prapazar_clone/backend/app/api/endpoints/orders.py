"""Sipariş yönetimi endpoint'leri."""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List, Optional
from datetime import datetime

from app.api.deps import get_db, get_current_user
from app.crud.order import order_crud
from app.crud.store import store_crud
from app.schemas.order import OrderResponse, OrderListResponse, OrderUpdate, ShipmentUpdate
from app.models.user import User

router = APIRouter(prefix="/orders", tags=["Siparişler"])


@router.get("/", response_model=OrderListResponse)
async def list_orders(
    skip: int = 0,
    limit: int = 50,
    status: Optional[str] = None,
    date_from: Optional[datetime] = None,
    date_to: Optional[datetime] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Siparişleri listele."""
    orders, total = await order_crud.get_by_owner(
        db,
        owner_id=current_user.id,
        skip=skip,
        limit=limit,
        status=status,
        date_from=date_from,
        date_to=date_to
    )

    return OrderListResponse(
        items=orders,
        total=total,
        page=skip // limit + 1,
        page_size=limit,
        total_pages=(total + limit - 1) // limit
    )


@router.get("/stats")
async def get_order_stats(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Sipariş istatistikleri."""
    return await order_crud.get_order_stats(db, owner_id=current_user.id)


@router.get("/today", response_model=List[OrderResponse])
async def get_today_orders(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Bugünkü siparişleri getir."""
    return await order_crud.get_today_orders(db, owner_id=current_user.id)


@router.get("/{order_id}", response_model=OrderResponse)
async def get_order(
    order_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Sipariş detayı."""
    order = await order_crud.get_with_items(db, id=order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Sipariş bulunamadı")

    # Sahiplik kontrolü
    store = await store_crud.get(db, id=order.store_id)
    if not store or store.owner_id != current_user.id:
        raise HTTPException(status_code=404, detail="Sipariş bulunamadı")

    return order


@router.put("/{order_id}", response_model=OrderResponse)
async def update_order(
    order_id: int,
    order_update: OrderUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Sipariş güncelle."""
    order = await order_crud.get(db, id=order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Sipariş bulunamadı")

    store = await store_crud.get(db, id=order.store_id)
    if not store or store.owner_id != current_user.id:
        raise HTTPException(status_code=404, detail="Sipariş bulunamadı")

    updated = await order_crud.update(db, db_obj=order, obj_in=order_update)

    # Durum değişikliğini pazaryerine bildir
    if order_update.status and order_update.status != order.status:
        from app.tasks.sync_tasks import update_order_status
        await update_order_status(order_id, order_update.status)

    return await order_crud.get_with_items(db, id=updated.id)


@router.post("/{order_id}/shipment")
async def update_shipment(
    order_id: int,
    shipment: ShipmentUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Kargo bilgisi güncelle."""
    order = await order_crud.get(db, id=order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Sipariş bulunamadı")

    store = await store_crud.get(db, id=order.store_id)
    if not store or store.owner_id != current_user.id:
        raise HTTPException(status_code=404, detail="Sipariş bulunamadı")

    # Siparişi güncelle
    order.cargo_company = shipment.cargo_company
    order.tracking_number = shipment.tracking_number
    order.status = "shipped"
    order.shipped_at = datetime.utcnow()

    await db.commit()
    await db.refresh(order)

    # Kargo bilgisini pazaryerine gönder
    from app.tasks.sync_tasks import send_shipment_info
    await send_shipment_info(order_id, shipment.cargo_company, shipment.tracking_number)

    return {"message": "Kargo bilgisi güncellendi", "order_id": order_id}


@router.post("/{order_id}/cancel")
async def cancel_order(
    order_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Sipariş iptal et."""
    order = await order_crud.get(db, id=order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Sipariş bulunamadı")

    store = await store_crud.get(db, id=order.store_id)
    if not store or store.owner_id != current_user.id:
        raise HTTPException(status_code=404, detail="Sipariş bulunamadı")

    if order.status in ["delivered", "cancelled"]:
        raise HTTPException(status_code=400, detail="Bu sipariş iptal edilemez")

    order.status = "cancelled"
    await db.commit()

    # İptali pazaryerine bildir
    from app.tasks.sync_tasks import cancel_platform_order
    await cancel_platform_order(order_id)

    return {"message": "Sipariş iptal edildi", "order_id": order_id}
