"""Ürün yönetimi endpoint'leri."""
from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List, Optional

from app.api.deps import get_db, get_current_user
from app.crud.product import product_crud
from app.crud.store import store_crud
from app.schemas.product import (
    ProductCreate, ProductUpdate, ProductResponse, ProductListResponse,
    BulkProductUpdate, BulkPlatformSync
)
from app.models.user import User
from app.models.product import Product
from app.models.product_platform import ProductPlatform

router = APIRouter(prefix="/products", tags=["Ürünler"])


@router.get("/", response_model=ProductListResponse)
async def list_products(
    skip: int = 0,
    limit: int = 50,
    search: Optional[str] = None,
    category_id: Optional[int] = None,
    is_active: Optional[bool] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Ürünleri listele."""
    products, total = await product_crud.get_by_owner(
        db,
        owner_id=current_user.id,
        skip=skip,
        limit=limit,
        search=search,
        category_id=category_id,
        is_active=is_active
    )

    return ProductListResponse(
        items=products,
        total=total,
        page=skip // limit + 1,
        page_size=limit,
        total_pages=(total + limit - 1) // limit
    )


@router.post("/", response_model=ProductResponse, status_code=status.HTTP_201_CREATED)
async def create_product(
    product_in: ProductCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Yeni ürün ekle."""
    # SKU kontrolü
    existing = await product_crud.get_by_sku(db, sku=product_in.sku, owner_id=current_user.id)
    if existing:
        raise HTTPException(status_code=400, detail="Bu SKU zaten kullanımda")

    product_data = product_in.model_dump()
    product_data["owner_id"] = current_user.id

    product = await product_crud.create(db, obj_in=product_data)
    return await product_crud.get_with_relations(db, id=product.id)


@router.get("/{product_id}", response_model=ProductResponse)
async def get_product(
    product_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Ürün detayı."""
    product = await product_crud.get_with_relations(db, id=product_id)
    if not product or product.owner_id != current_user.id:
        raise HTTPException(status_code=404, detail="Ürün bulunamadı")
    return product


@router.put("/{product_id}", response_model=ProductResponse)
async def update_product(
    product_id: int,
    product_update: ProductUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Ürün güncelle."""
    product = await product_crud.get(db, id=product_id)
    if not product or product.owner_id != current_user.id:
        raise HTTPException(status_code=404, detail="Ürün bulunamadı")

    updated = await product_crud.update(db, db_obj=product, obj_in=product_update)
    return await product_crud.get_with_relations(db, id=updated.id)


@router.delete("/{product_id}")
async def delete_product(
    product_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Ürün sil."""
    product = await product_crud.get(db, id=product_id)
    if not product or product.owner_id != current_user.id:
        raise HTTPException(status_code=404, detail="Ürün bulunamadı")

    await product_crud.remove(db, id=product_id)
    return {"message": "Ürün başarıyla silindi"}


@router.get("/low-stock", response_model=List[ProductResponse])
async def get_low_stock_products(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Düşük stoklu ürünleri getir."""
    return await product_crud.get_low_stock(db, owner_id=current_user.id)


@router.post("/bulk-update")
async def bulk_update_products(
    bulk_update: BulkProductUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Toplu ürün güncelleme."""
    from sqlalchemy import update

    # Ürünlerin sahibini kontrol et
    products = await product_crud.get_multi(
        db, 
        filters={"owner_id": current_user.id, "id": bulk_update.product_ids}
    )

    valid_ids = [p.id for p in products]

    if not valid_ids:
        raise HTTPException(status_code=404, detail="Güncellenecek ürün bulunamadı")

    # Güncelleme yap
    await db.execute(
        update(Product)
        .where(Product.id.in_(valid_ids))
        .values({bulk_update.field: bulk_update.value})
    )
    await db.commit()

    return {"message": f"{len(valid_ids)} ürün güncellendi", "updated_count": len(valid_ids)}


@router.post("/{product_id}/sync/{store_id}")
async def sync_product_to_store(
    product_id: int,
    store_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Ürünü belirli bir mağazaya senkronize et."""
    product = await product_crud.get_with_relations(db, id=product_id)
    if not product or product.owner_id != current_user.id:
        raise HTTPException(status_code=404, detail="Ürün bulunamadı")

    store = await store_crud.get(db, id=store_id)
    if not store or store.owner_id != current_user.id:
        raise HTTPException(status_code=404, detail="Mağaza bulunamadı")

    if not store.is_connected:
        raise HTTPException(status_code=400, detail="Mağaza bağlı değil")

    # Senkronizasyon görevini başlat
    from app.tasks.sync_tasks import sync_single_product
    await sync_single_product(product_id, store_id)

    return {"message": "Senkronizasyon başlatıldı", "product_id": product_id, "store_id": store_id}


@router.post("/import-excel")
async def import_products_excel(
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Excel dosyasından ürün içe aktar."""
    import pandas as pd
    from io import BytesIO

    contents = await file.read()
    df = pd.read_excel(BytesIO(contents))

    # Gerekli kolonları kontrol et
    required_columns = ["sku", "title", "base_price", "stock_quantity"]
    missing = [col for col in required_columns if col not in df.columns]
    if missing:
        raise HTTPException(status_code=400, detail=f"Eksik kolonlar: {', '.join(missing)}")

    imported = 0
    updated = 0

    for _, row in df.iterrows():
        sku = str(row["sku"])
        existing = await product_crud.get_by_sku(db, sku=sku, owner_id=current_user.id)

        product_data = {
            "sku": sku,
            "title": str(row["title"]),
            "base_price": float(row["base_price"]),
            "stock_quantity": int(row["stock_quantity"]),
            "owner_id": current_user.id,
            "barcode": str(row.get("barcode", "")),
            "description": str(row.get("description", "")),
            "brand": str(row.get("brand", "")),
            "category_id": int(row.get("category_id")) if pd.notna(row.get("category_id")) else None,
        }

        if existing:
            await product_crud.update(db, db_obj=existing, obj_in=product_data)
            updated += 1
        else:
            await product_crud.create(db, obj_in=product_data)
            imported += 1

    return {
        "message": f"İçe aktarma tamamlandı",
        "imported": imported,
        "updated": updated,
        "total": imported + updated
    }
