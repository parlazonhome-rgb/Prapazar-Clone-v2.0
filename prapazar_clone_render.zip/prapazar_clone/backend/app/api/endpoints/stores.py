"""Mağaza yönetimi endpoint'leri."""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List

from app.api.deps import get_db, get_current_user
from app.crud.store import store_crud
from app.schemas.store import StoreCreate, StoreUpdate, StoreResponse, StoreConnectionTest
from app.models.user import User
from app.models.store import Store
from app.services.platforms.trendyol import TrendyolService
from app.services.platforms.hepsiburada import HepsiburadaService
from app.services.platforms.n11 import N11Service
from app.services.platforms.koctas import KoctasService
from app.services.platforms.pazarama import PazaramaService
from app.services.platforms.pttavm import PttAvmService

router = APIRouter(prefix="/stores", tags=["Mağazalar"])


def get_platform_service(store: Store):
    """Platforma göre servis döndür."""
    services = {
        "trendyol": TrendyolService,
        "hepsiburada": HepsiburadaService,
        "n11": N11Service,
        "koctas": KoctasService,
        "pazarama": PazaramaService,
        "pttavm": PttAvmService,
    }
    service_class = services.get(store.platform)
    if not service_class:
        raise HTTPException(status_code=400, detail=f"Desteklenmeyen platform: {store.platform}")
    return service_class(store)


@router.get("/", response_model=List[StoreResponse])
async def list_stores(
    skip: int = 0,
    limit: int = 100,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Kullanıcının mağazalarını listele."""
    return await store_crud.get_by_owner(db, owner_id=current_user.id, skip=skip, limit=limit)


@router.post("/", response_model=StoreResponse, status_code=status.HTTP_201_CREATED)
async def create_store(
    store_in: StoreCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Yeni mağaza ekle."""
    store_data = store_in.model_dump()
    store_data["owner_id"] = current_user.id
    store_data["is_connected"] = False

    store = await store_crud.create(db, obj_in=store_data)
    return store


@router.get("/{store_id}", response_model=StoreResponse)
async def get_store(
    store_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Mağaza detayı."""
    store = await store_crud.get(db, id=store_id)
    if not store or store.owner_id != current_user.id:
        raise HTTPException(status_code=404, detail="Mağaza bulunamadı")
    return store


@router.put("/{store_id}", response_model=StoreResponse)
async def update_store(
    store_id: int,
    store_update: StoreUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Mağaza güncelle."""
    store = await store_crud.get(db, id=store_id)
    if not store or store.owner_id != current_user.id:
        raise HTTPException(status_code=404, detail="Mağaza bulunamadı")

    updated = await store_crud.update(db, db_obj=store, obj_in=store_update)
    return updated


@router.delete("/{store_id}")
async def delete_store(
    store_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Mağaza sil."""
    store = await store_crud.get(db, id=store_id)
    if not store or store.owner_id != current_user.id:
        raise HTTPException(status_code=404, detail="Mağaza bulunamadı")

    await store_crud.remove(db, id=store_id)
    return {"message": "Mağaza başarıyla silindi"}


@router.post("/{store_id}/test-connection", response_model=StoreConnectionTest)
async def test_connection(
    store_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Mağaza API bağlantısını test et."""
    store = await store_crud.get(db, id=store_id)
    if not store or store.owner_id != current_user.id:
        raise HTTPException(status_code=404, detail="Mağaza bulunamadı")

    try:
        service = get_platform_service(store)
        result = await service.test_connection()

        # Bağlantı başarılıysa güncelle
        if result.get("success"):
            store.is_connected = True
            await db.commit()

        return StoreConnectionTest(**result)

    except Exception as e:
        return StoreConnectionTest(
            success=False,
            message=f"Bağlantı hatası: {str(e)}"
        )


@router.post("/{store_id}/sync")
async def sync_store(
    store_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Mağazayı manuel senkronize et."""
    store = await store_crud.get(db, id=store_id)
    if not store or store.owner_id != current_user.id:
        raise HTTPException(status_code=404, detail="Mağaza bulunamadı")

    if not store.is_connected:
        raise HTTPException(status_code=400, detail="Mağaza bağlı değil. Önce bağlantı testi yapın.")

    # Senkronizasyon görevini kuyruğa ekle
    from app.tasks.sync_tasks import sync_store_products, sync_store_orders

    await sync_store_products(store_id)
    await sync_store_orders(store_id)

    return {"message": "Senkronizasyon başlatıldı", "store_id": store_id}
