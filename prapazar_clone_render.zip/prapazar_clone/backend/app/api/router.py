"""API Router."""
from fastapi import APIRouter

from app.api.endpoints import auth, users, stores, products, categories, orders

api_router = APIRouter()

api_router.include_router(auth.router, prefix="/auth", tags=["Kimlik Doğrulama"])
api_router.include_router(users.router, prefix="/users", tags=["Kullanıcılar"])
api_router.include_router(stores.router, prefix="/stores", tags=["Mağazalar"])
api_router.include_router(products.router, prefix="/products", tags=["Ürünler"])
api_router.include_router(categories.router, prefix="/categories", tags=["Kategoriler"])
api_router.include_router(orders.router, prefix="/orders", tags=["Siparişler"])
