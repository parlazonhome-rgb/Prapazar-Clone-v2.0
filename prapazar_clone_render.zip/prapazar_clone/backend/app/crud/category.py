"""Kategori CRUD işlemleri."""
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import List

from app.models.category import Category
from app.schemas.category import CategoryCreate, CategoryUpdate
from app.utils.crud_base import CRUDBase


class CRUDCategory(CRUDBase[Category, CategoryCreate, CategoryUpdate]):
    """Kategori CRUD."""

    async def get_by_owner(
        self,
        db: AsyncSession,
        owner_id: int,
        skip: int = 0,
        limit: int = 100
    ) -> List[Category]:
        """Sahibine göre kategorileri getir."""
        result = await db.execute(
            select(Category)
            .where(Category.owner_id == owner_id)
            .offset(skip)
            .limit(limit)
        )
        return result.scalars().all()

    async def get_root_categories(self, db: AsyncSession, owner_id: int) -> List[Category]:
        """Ana kategorileri getir (parent_id = None)."""
        result = await db.execute(
            select(Category)
            .where(Category.owner_id == owner_id)
            .where(Category.parent_id == None)
        )
        return result.scalars().all()


category_crud = CRUDCategory(Category)
