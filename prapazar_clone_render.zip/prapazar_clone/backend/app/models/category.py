"""Kategori modeli."""
from sqlalchemy import Column, Integer, String, Text, ForeignKey, Boolean
from sqlalchemy.orm import relationship
from app.models.base import Base, TimestampMixin


class Category(Base, TimestampMixin):
    """Ürün kategorisi."""
    __tablename__ = "categories"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(200), nullable=False)
    description = Column(Text)
    parent_id = Column(Integer, ForeignKey("categories.id"), nullable=True)

    # Pazaryeri kategori eşleştirmeleri
    trendyol_category_id = Column(String(100))
    hepsiburada_category_id = Column(String(100))
    n11_category_id = Column(String(100))
    gittigidiyor_category_id = Column(String(100))
    koctas_category_id = Column(String(100))
    pazarama_category_id = Column(String(100))
    pttavm_category_id = Column(String(100))

    is_active = Column(Boolean, default=True)

    # Foreign Keys
    owner_id = Column(Integer, ForeignKey("users.id"), nullable=False)

    # İlişkiler
    owner = relationship("User", back_populates="categories")
    products = relationship("Product", back_populates="category")
    children = relationship("Category", backref="parent", remote_side=[id])
