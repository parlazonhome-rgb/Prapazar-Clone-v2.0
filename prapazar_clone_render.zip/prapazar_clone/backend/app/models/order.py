"""Sipariş modeli."""
from sqlalchemy import Column, Integer, String, Float, Boolean, ForeignKey, JSON, DateTime, Text
from sqlalchemy.orm import relationship
from app.models.base import Base, TimestampMixin


class Order(Base, TimestampMixin):
    """Pazaryeri siparişi."""
    __tablename__ = "orders"

    id = Column(Integer, primary_key=True, index=True)

    # Sipariş bilgileri
    order_number = Column(String(100), index=True, nullable=False)  # Bizim sistemdeki sipariş no
    platform_order_id = Column(String(100), index=True)  # Pazaryerindeki sipariş ID
    platform_order_number = Column(String(100))  # Pazaryerindeki sipariş no

    # Durum
    status = Column(String(50), default="new")  # new, confirmed, preparing, shipped, delivered, cancelled, returned
    platform_status = Column(String(50))  # Pazaryerinin orijinal durumu

    # Müşteri
    customer_name = Column(String(200))
    customer_email = Column(String(255))
    customer_phone = Column(String(20))
    shipping_address = Column(JSON)  # {"city": "İstanbul", "district": "Kadıköy", "address": "...", "zip": "34000"}
    billing_address = Column(JSON)

    # Fiyat
    subtotal = Column(Float, default=0.0)  # Ürün toplamı
    shipping_cost = Column(Float, default=0.0)  # Kargo
    discount = Column(Float, default=0.0)  # İndirim
    tax = Column(Float, default=0.0)  # Vergi
    total = Column(Float, default=0.0)  # Genel toplam
    commission_amount = Column(Float, default=0.0)  # Komisyon

    # Kargo
    cargo_company = Column(String(100))
    tracking_number = Column(String(100))
    shipped_at = Column(DateTime(timezone=True))
    delivered_at = Column(DateTime(timezone=True))

    # Notlar
    customer_note = Column(Text)
    internal_note = Column(Text)

    # Meta
    platform_data = Column(JSON, default=dict)

    # Foreign Keys
    store_id = Column(Integer, ForeignKey("stores.id"), nullable=False)

    # İlişkiler
    store = relationship("Store", back_populates="orders")
    items = relationship("OrderItem", back_populates="order", cascade="all, delete-orphan")
