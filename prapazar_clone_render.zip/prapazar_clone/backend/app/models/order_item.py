"""Sipariş kalemi modeli."""
from sqlalchemy import Column, Integer, String, Float, ForeignKey
from sqlalchemy.orm import relationship
from app.models.base import Base


class OrderItem(Base):
    """Sipariş kalemi."""
    __tablename__ = "order_items"

    id = Column(Integer, primary_key=True, index=True)

    # Ürün bilgileri
    product_name = Column(String(500), nullable=False)
    product_sku = Column(String(100))
    product_barcode = Column(String(100))
    variant_info = Column(String(200))  # "Kırmızı - M"

    # Fiyat
    unit_price = Column(Float, default=0.0)
    quantity = Column(Integer, default=1)
    total_price = Column(Float, default=0.0)

    # Foreign Keys
    order_id = Column(Integer, ForeignKey("orders.id"), nullable=False)
    product_id = Column(Integer, ForeignKey("products.id"))

    # İlişkiler
    order = relationship("Order", back_populates="items")
