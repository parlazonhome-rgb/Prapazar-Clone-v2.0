"""Ürün modeli."""
from sqlalchemy import Column, Integer, String, Text, Float, Boolean, ForeignKey, JSON, DateTime
from sqlalchemy.orm import relationship
from app.models.base import Base, TimestampMixin


class Product(Base, TimestampMixin):
    """Ana ürün modeli."""
    __tablename__ = "products"

    id = Column(Integer, primary_key=True, index=True)
    sku = Column(String(100), unique=True, index=True, nullable=False)  # Stok kodu
    barcode = Column(String(100), index=True)  # Barkod
    title = Column(String(500), nullable=False)
    description = Column(Text)
    short_description = Column(String(500))

    # Fiyat
    purchase_price = Column(Float, default=0.0)  # Alış fiyatı
    base_price = Column(Float, default=0.0)  # Temel satış fiyatı

    # Stok
    stock_quantity = Column(Integer, default=0)
    stock_alert_level = Column(Integer, default=5)  # Stok uyarı seviyesi

    # Özellikler
    brand = Column(String(100))
    weight = Column(Float)  # kg
    dimensions = Column(JSON)  # {"length": 10, "width": 5, "height": 3}

    # Görseller
    images = Column(JSON, default=list)  # ["url1", "url2", ...]
    main_image = Column(String(500))

    # Varyantlar
    has_variants = Column(Boolean, default=False)
    variant_attributes = Column(JSON, default=list)  # [{"name": "Renk", "values": ["Kırmızı", "Mavi"]}]

    # Durum
    is_active = Column(Boolean, default=True)
    is_approved = Column(Boolean, default=False)  # Onay durumu

    # Meta
    meta_title = Column(String(200))
    meta_description = Column(String(500))
    tags = Column(JSON, default=list)

    # Foreign Keys
    owner_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    category_id = Column(Integer, ForeignKey("categories.id"))

    # İlişkiler
    owner = relationship("User", back_populates="products")
    category = relationship("Category", back_populates="products")
    variants = relationship("ProductVariant", back_populates="product", cascade="all, delete-orphan")
    platforms = relationship("ProductPlatform", back_populates="product", cascade="all, delete-orphan")
