"""Ürün-Pazaryeri eşleştirme modeli."""
from sqlalchemy import Column, Integer, String, Float, Boolean, ForeignKey, JSON, DateTime, Text
from sqlalchemy.orm import relationship
from app.models.base import Base, TimestampMixin


class ProductPlatform(Base, TimestampMixin):
    """Ürünün pazaryerindeki durumu."""
    __tablename__ = "product_platforms"

    id = Column(Integer, primary_key=True, index=True)

    # Pazaryeri bilgileri
    platform_product_id = Column(String(100))  # Pazaryerindeki ürün ID
    platform_sku = Column(String(100))  # Pazaryerindeki SKU
    platform_listing_url = Column(String(500))  # Ürün sayfası URL

    # Fiyat (pazaryeri özel)
    platform_price = Column(Float, default=0.0)
    platform_sale_price = Column(Float, default=0.0)

    # Stok
    platform_stock = Column(Integer, default=0)

    # Durum
    status = Column(String(50), default="draft")  # draft, pending, active, rejected, paused, out_of_stock
    sync_status = Column(String(50), default="pending")  # pending, syncing, synced, failed
    last_sync_at = Column(DateTime(timezone=True))
    last_sync_error = Column(Text)

    # Meta
    platform_data = Column(JSON, default=dict)  # Pazaryeri özel veriler

    # Foreign Keys
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)
    store_id = Column(Integer, ForeignKey("stores.id"), nullable=False)

    # İlişkiler
    product = relationship("Product", back_populates="platforms")
    store = relationship("Store", back_populates="product_platforms")
