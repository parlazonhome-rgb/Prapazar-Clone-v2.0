"""Ürün varyant modeli."""
from sqlalchemy import Column, Integer, String, Float, Boolean, ForeignKey, JSON
from sqlalchemy.orm import relationship
from app.models.base import Base, TimestampMixin


class ProductVariant(Base, TimestampMixin):
    """Ürün varyantı (Renk, Beden vb.)."""
    __tablename__ = "product_variants"

    id = Column(Integer, primary_key=True, index=True)
    sku = Column(String(100), unique=True, index=True, nullable=False)
    barcode = Column(String(100), index=True)

    # Varyant özellikleri
    attributes = Column(JSON, default=dict)  # {"Renk": "Kırmızı", "Beden": "M"}

    # Fiyat
    price = Column(Float, default=0.0)

    # Stok
    stock_quantity = Column(Integer, default=0)

    # Görseller
    images = Column(JSON, default=list)

    is_active = Column(Boolean, default=True)

    # Foreign Keys
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)

    # İlişkiler
    product = relationship("Product", back_populates="variants")
