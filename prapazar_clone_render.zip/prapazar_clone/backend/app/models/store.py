"""Mağaza modeli - Her pazaryeri hesabı."""
from sqlalchemy import Column, Integer, String, Boolean, Text, ForeignKey, DateTime, Float
from sqlalchemy.orm import relationship
from app.models.base import Base, TimestampMixin


class Store(Base, TimestampMixin):
    """Pazaryeri mağazası."""
    __tablename__ = "stores"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(200), nullable=False)
    platform = Column(String(50), nullable=False)  # trendyol, hepsiburada, n11, gittigidiyor
    store_name = Column(String(200))  # Pazaryerindeki mağaza adı
    seller_id = Column(String(100))  # Satıcı ID
    api_key = Column(String(500))  # API Key (şifreli saklanmalı)
    api_secret = Column(String(500))  # API Secret (şifreli saklanmalı)
    base_url = Column(String(500))  # API Base URL
    is_active = Column(Boolean, default=True)
    is_connected = Column(Boolean, default=False)  # API bağlantısı aktif mi?
    last_sync_at = Column(DateTime(timezone=True))
    sync_interval_minutes = Column(Integer, default=15)  # Otomatik senkronizasyon aralığı
    commission_rate = Column(Float, default=0.0)  # Komisyon oranı

    # Foreign Keys
    owner_id = Column(Integer, ForeignKey("users.id"), nullable=False)

    # İlişkiler
    owner = relationship("User", back_populates="stores")
    product_platforms = relationship("ProductPlatform", back_populates="store", cascade="all, delete-orphan")
    orders = relationship("Order", back_populates="store", cascade="all, delete-orphan")
